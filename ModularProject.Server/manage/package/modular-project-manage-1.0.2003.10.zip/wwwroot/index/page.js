var pg = {};

pg.openPages = function (group, item) {
    $jttp.postApi("/modular-project-manage/api/tools/openpages", { Group: group, Item: item }, function (e) {
        alert("使用VS编辑Pages命令执行成功!");
    }, function (e) {
        alert(e.Message);
    });
}

$(function () {

});